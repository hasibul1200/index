<?php
// server.php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    // Log the input (for demonstration purposes)
    file_put_contents('logs.txt', "Name: $name, Email: $email, Message: $message\n", FILE_APPEND);

    echo "Thank you for your message, $name!";
}
?>
