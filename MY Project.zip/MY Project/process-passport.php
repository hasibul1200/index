<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = htmlspecialchars($_POST['full_name']);
    $dob = htmlspecialchars($_POST['dob']);
    $national_id = htmlspecialchars($_POST['national_id']);
    $email = htmlspecialchars($_POST['email']);
    $address = htmlspecialchars($_POST['address']);

    // Handle the uploaded photo
    $photo = $_FILES['photo'];
    $upload_dir = 'uploads/';
    $upload_file = $upload_dir . basename($photo['name']);
    
    if (move_uploaded_file($photo['tmp_name'], $upload_file)) {
        $photo_url = $upload_file;
    } else {
        die("Error uploading photo. Please try again.");
    }

    // Save data to a file (or connect to a database)
    $data = "Name: $full_name\nDOB: $dob\nNational ID: $national_id\nEmail: $email\nAddress: $address\nPhoto: $photo_url\n\n";
    file_put_contents('applications.txt', $data, FILE_APPEND);

    echo "Thank you, $full_name. Your application has been submitted successfully.";
} else {
    echo "Invalid request method.";
}
?>
