<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $applicant_name = htmlspecialchars($_POST['applicant_name']);
    $land_id = htmlspecialchars($_POST['land_id']);
    $location = htmlspecialchars($_POST['location']);
    $reason = htmlspecialchars($_POST['reason']);

    // Handle the uploaded ownership document
    $ownership_doc = $_FILES['ownership_doc'];
    $upload_dir = 'land_docs/';
    $upload_file = $upload_dir . basename($ownership_doc['name']);
    
    if (move_uploaded_file($ownership_doc['tmp_name'], $upload_file)) {
        $ownership_doc_url = $upload_file;
    } else {
        die("Error uploading document. Please try again.");
    }

    // Save data to a file (or connect to a database)
    $data = "Applicant: $applicant_name\nLID: $land_id\nLocation: $location\nReason: $reason\nDocument: $ownership_doc_url\n\n";
    file_put_contents('land_records.txt', $data, FILE_APPEND);

    echo "Thank you, $applicant_name. Your land records application has been submitted successfully.";
} else {
    echo "Invalid request method.";
}
?>
