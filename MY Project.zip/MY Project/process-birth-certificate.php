<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = htmlspecialchars($_POST['full_name']);
    $dob = htmlspecialchars($_POST['dob']);
    $birth_place = htmlspecialchars($_POST['birth_place']);
    $father_name = htmlspecialchars($_POST['father_name']);
    $mother_name = htmlspecialchars($_POST['mother_name']);

    // Handle the uploaded document
    $proof_doc = $_FILES['proof_doc'];
    $upload_dir = 'birth_docs/';
    $upload_file = $upload_dir . basename($proof_doc['name']);
    
    if (move_uploaded_file($proof_doc['tmp_name'], $upload_file)) {
        $proof_doc_url = $upload_file;
    } else {
        die("Error uploading document. Please try again.");
    }

    // Save data to a file (or connect to a database)
    $data = "Name: $full_name\nDOB: $dob\nPlace of Birth: $birth_place\nFather's Name: $father_name\nMother's Name: $mother_name\nDocument: $proof_doc_url\n\n";
    file_put_contents('birth_certificates.txt', $data, FILE_APPEND);

    echo "Thank you, $full_name. Your birth certificate application has been submitted successfully.";
} else {
    echo "Invalid request method.";
}
?>
