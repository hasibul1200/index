<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = htmlspecialchars($_POST['full_name']);
    $tax_id = htmlspecialchars($_POST['tax_id']);
    $dob = htmlspecialchars($_POST['dob']);
    $income = htmlspecialchars($_POST['income']);

    // Handle the uploaded tax document
    $tax_doc = $_FILES['tax_doc'];
    $upload_dir = 'tax_documents/';
    $upload_file = $upload_dir . basename($tax_doc['name']);
    
    if (move_uploaded_file($tax_doc['tmp_name'], $upload_file)) {
        $tax_doc_url = $upload_file;
    } else {
        die("Error uploading document. Please try again.");
    }

    // Save data to a file (or connect to a database)
    $data = "Name: $full_name\nTIN: $tax_id\nDOB: $dob\nIncome: $income\nDocument: $tax_doc_url\n\n";
    file_put_contents('tax_filings.txt', $data, FILE_APPEND);

    echo "Thank you, $full_name. Your tax filing has been submitted successfully.";
} else {
    echo "Invalid request method.";
}
?>
